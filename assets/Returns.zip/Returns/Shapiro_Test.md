import pandas as pd
import numpy as np
from scipy.stats import shapiro


# === FILE PATHS ===
input_path = 'LB_Test_Results.xlsx'
output_path = 'normality_summary.xlsx'

# === PARAMETERS ===
target_columns = ['Return_30', 'Return_60', 'Return_90', 'Return_120']
segments = [30,60,90,120]
xls = pd.read_excel(input_path, sheet_name = None)

processed_sheets = {}

with pd.ExcelWriter(output_path) as writer:
    for sheet_name, df in xls.items():
         print(f"Processing sheet: {sheet_name}")
         P = []
    
         for col, seg_size in zip(target_columns, segments):
            if col in df.columns:
                data = df[col].dropna().reset_index(drop=True)  # what does this do
                G = [None] * int(np.floor(len(data) / seg_size))
                
                k = 0
                p = seg_size
                for i in range(int(np.floor(len(data) / seg_size))):
                    x = data[k:p]
                    shapiro_test = stats.shapiro(x)
                    h = shapiro_test.pvalue
    
                    if h < 0.05:
                        G[i] = 'Not a Normal fit'
                    else:
                        G[i] = 'Normal fit'
                    k = k + seg_size
                    p = p + seg_size
    
            total = len(G)
            count = G.count('Not a Normal fit')
            percentage = (count / total) * 100
            P.append([seg_size, total, percentage])

        
         
         result_df = pd.DataFrame(P, columns =['Segment_size', 'Total', 'Percentage'])
         result_df.to_excel(writer, sheet_name=sheet_name, index=False)          
