function output = Ljungtestfordata(a, Dates, b, c, d)

% Compute Returns
if strcmp(b, 'Window')
    if strcmp(c, 'Daily')
        Returns = cell(length(a)-1,2);
        Returns(:,2) = num2cell(tick2ret(a));
        Returns(:,1) = cellstr(Dates(2:end));
    elseif strcmp(c, 'Weekly')
        n = 5; k = 5; q = 1;
        Returns = cell(floor(length(a)/n), 2);
        for i = 1:length(Returns)
            Returns{i,2} = log(a(k)) - log(a(q));
            Returns{i,1} = cellstr(Dates(k));
            k = k + n; q = q + n;
        end
    elseif strcmp(c, 'Monthly')
        n = 30; k = 30; q = 1;
        Returns = cell(floor(length(a)/n), 2);
        for i = 1:length(Returns)
            Returns{i,2} = log(a(k)) - log(a(q));
            Returns{i,1} = cellstr(Dates(k));
            k = k + n; q = q + n;
        end
    elseif strcmp(c, 'Quarterly')
        n = 90; k = 90; q = 1;
        Returns = cell(floor(length(a)/n), 2);
        for i = 1:length(Returns)
            Returns{i,2} = log(a(k)) - log(a(q));
            Returns{i,1} = cellstr(Dates(k));
            k = k + n; q = q + n;
        end
    end
elseif strcmp(b, 'Rolling')
    if strcmp(c, 'Daily')
        Returns = cell(length(a)-1,2);
        Returns(:,2) = num2cell(tick2ret(a));
        Returns(:,1) = cellstr(Dates(2:(length(Dates))));
    elseif strcmp(c, 'Weekly')
        n = 5;
        Returns = cell(length(a)-n,2);
        
        for i = 1:length(Returns)
            Returns{i,1} = cellstr(Dates(i + n));
            Returns{i,2} = log(a(i + n)) - log(a(i));
        end
    elseif strcmp(c, 'Monthly')
        n = 30;
        Returns = cell(length(a)-n,2);
        
        for i = 1:length(Returns)
           Returns{i,1} = cellstr(Dates(i + n));
           Returns{i,2} = log(a(i + n)) - log(a(i));
        end
    elseif strcmp(c, 'Quarterly')
        n = 90;
        Returns = cell(length(a)-n,2);
        for i = 1:length(Returns)
            Returns{i,1} = cellstr(Dates(i + n));
            Returns{i,2} = log(a(i + n)) - log(a(i));
        end
    end
end

% LB Test over each window in d
P = {};
count = 1;
 for i = d
    k =1;
    n = i;
    numSegments = floor(length(Returns) / i);
    A = {};

     for p = 1:numSegments 
     x = cell2mat(Returns(k:n,2));
     h = lbqtest(x,Lags=floor(log(i)));

         if h == 0
            A = [A; Returns(k:n,:)];
         end
     k = k + i;
     n = n + i;
     end
  P {count} = A;
  count = count +1;
 end

maxLen = max(cellfun(@(x) size(x,1), P));
output = cell(maxLen, 2 * length(P));

for i = 1:length(P)
    r = size(P{i}, 1);
    output(1:r, (2*i-1):(2*i)) = P{i};  % Direct cell assignment
end

